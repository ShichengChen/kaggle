# 预备知识

```eval_rst

.. toctree::
   :maxdepth: 2

   introduction
   ndarray
   autograd

```
