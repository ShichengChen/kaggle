# Gluon高级


```eval_rst

.. toctree::
   :maxdepth: 2

   hybridize
   lazy-evaluation
   auto-parallelism
   multiple-gpus-scratch
   multiple-gpus-gluon
```
