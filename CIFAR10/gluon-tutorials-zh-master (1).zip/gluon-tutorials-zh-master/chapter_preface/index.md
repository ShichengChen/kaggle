# 前言

```eval_rst

.. toctree::
   :maxdepth: 2

   why
   preface
   install
   buy-gpu
   aws
```
