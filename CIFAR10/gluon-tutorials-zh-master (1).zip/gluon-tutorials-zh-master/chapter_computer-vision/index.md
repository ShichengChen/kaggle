# 计算机视觉


```eval_rst

.. toctree::
   :maxdepth: 2

   image-augmentation
   fine-tuning
   object-detection
   ssd
   fcn
   kaggle-gluon-cifar10
   kaggle-gluon-dog
```
