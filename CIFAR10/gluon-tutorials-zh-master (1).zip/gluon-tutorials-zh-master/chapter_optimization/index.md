# 优化算法


```eval_rst

.. toctree::
   :maxdepth: 2

   optimization-intro
   gd-sgd-scratch
   gd-sgd-gluon
   momentum-scratch
   momentum-gluon
   adagrad-scratch
   adagrad-gluon
   rmsprop-scratch
   rmsprop-gluon
   adadelta-scratch
   adadelta-gluon
   adam-scratch
   adam-gluon
```
