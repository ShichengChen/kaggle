netlib is now part of mitmproxy. This package does nothing but install mitmproxy.


